"""
EO/IR Surveillance & Command Operator Console — Production Release Candidate
Conforms to ICD-1.1 through ICD-3.2 Subsystem Specifications.
Runs with Python 3 standard library only:
    python app.py
"""
from http.server import BaseHTTPRequestHandler, HTTPServer
import copy
import html
import json
import urllib.parse

PORT = 8080

USERS = {
    "admin":    {"password": "admin123",    "role": "admin"},
    "operator": {"password": "operator123", "role": "operator"},
    "viewer":   {"password": "viewer123",   "role": "viewer"},
}

FRAMES = [
    {
        "frame_id": 0,
        "pts_ms": 1000,
        "scene_desc": "Frame 0: Convoy truck at x=80,y=140; Thermal clutter at x=490,y=70",
        "ground_truth_positions": [{"label": "vehicle (TRK-101)", "x": 80, "y": 140, "w": 90, "h": 45}],
        "detections": [
            {"track_id": "TRK-101", "class": "vehicle", "conf": 0.92, "bbox": [80, 140, 170, 185], "lat": 28.6139, "lon": 77.2090},
            {"track_id": "TRK-999", "class": "clutter", "conf": 0.22, "bbox": [490, 70, 530, 105], "lat": 28.6145, "lon": 77.2102},
        ],
    },
    {
        "frame_id": 1,
        "pts_ms": 1040,
        "scene_desc": "Frame 1: Convoy truck moved to x=150,y=140; Person enters at x=260,y=210",
        "ground_truth_positions": [
            {"label": "vehicle (TRK-101)", "x": 150, "y": 140, "w": 90, "h": 45},
            {"label": "person (TRK-102)",  "x": 260, "y": 210, "w": 30, "h": 60},
        ],
        "detections": [
            {"track_id": "TRK-101", "class": "vehicle", "conf": 0.89, "bbox": [150, 140, 240, 185], "lat": 28.6140, "lon": 77.2095},
            {"track_id": "TRK-102", "class": "person",  "conf": 0.76, "bbox": [260, 210, 290, 270], "lat": 28.6141, "lon": 77.2098},
        ],
    },
    {
        "frame_id": 2,
        "pts_ms": 1080,
        "scene_desc": "Frame 2: Convoy truck at x=230,y=140; Person at x=285,y=210",
        "ground_truth_positions": [
            {"label": "vehicle (TRK-101)", "x": 230, "y": 140, "w": 90, "h": 45},
            {"label": "person (TRK-102)",  "x": 285, "y": 210, "w": 30, "h": 60},
        ],
        "detections": [
            {"track_id": "TRK-101", "class": "vehicle", "conf": 0.94, "bbox": [230, 140, 320, 185], "lat": 28.6142, "lon": 77.2100},
            {"track_id": "TRK-102", "class": "person",  "conf": 0.81, "bbox": [285, 210, 315, 270], "lat": 28.6143, "lon": 77.2104},
        ],
    },
    {
        "frame_id": 3,
        "pts_ms": 1120,
        "scene_desc": "Frame 3: Convoy truck at x=310,y=140; Person at x=310,y=210 (occlusion)",
        "ground_truth_positions": [
            {"label": "vehicle (TRK-101)", "x": 310, "y": 140, "w": 90, "h": 45},
            {"label": "person (TRK-102)",  "x": 310, "y": 210, "w": 30, "h": 60},
        ],
        "detections": [
            {"track_id": "TRK-101", "class": "vehicle", "conf": 0.91, "bbox": [310, 140, 400, 185], "lat": 28.6144, "lon": 77.2108},
            {"track_id": "TRK-102", "class": "person",  "conf": 0.64, "bbox": [310, 210, 340, 270], "lat": 28.6145, "lon": 77.2111},
        ],
    },
]

INITIAL_ALERTS = [
    {"id": 1, "track_id": "TRK-101", "frame_id": 0, "class": "vehicle", "conf": 0.92, "lat": 28.6139, "lon": 77.2090, "severity": "HIGH"},
    {"id": 2, "track_id": "TRK-999", "frame_id": 0, "class": "clutter", "conf": 0.22, "lat": 28.6145, "lon": 77.2102, "severity": "LOW"},
    {"id": 3, "track_id": "TRK-102", "frame_id": 1, "class": "person",  "conf": 0.76, "lat": 28.6141, "lon": 77.2098, "severity": "MEDIUM"},
    {"id": 4, "track_id": "TRK-101", "frame_id": 2, "class": "vehicle", "conf": 0.94, "lat": 28.6142, "lon": 77.2100, "severity": "HIGH"},
    {"id": 5, "track_id": "TRK-102", "frame_id": 3, "class": "person",  "conf": 0.64, "lat": 28.6145, "lon": 77.2111, "severity": "MEDIUM"},
]

STATE = {
    "alerts": copy.deepcopy(INITIAL_ALERTS),
    "cameras": [
        {"id": "EO-NORTH-01", "name": "Sector-4 Thermal PTZ", "fps": 25, "status": "ONLINE"},
        {"id": "IR-EAST-02",  "name": "Perimeter IR Fixed",   "fps": 25, "status": "ONLINE"},
    ],
    "stream_reconnects": 0,
}

HTML_PAGE = """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>EO/IR Operator Command Console</title>
  <style>
    body { font-family: Segoe UI, sans-serif; margin: 0; background: #0f172a; color: #e2e8f0; }
    header { background: #1e293b; padding: 12px 20px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #334155; }
    .grid { display: grid; grid-template-columns: 1.2fr 1fr; gap: 16px; padding: 16px; }
    .card { background: #1e293b; border: 1px solid #334155; border-radius: 6px; padding: 14px; }
    canvas { background: #020617; border: 1px solid #475569; width: 600px; height: 300px; display: block; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 8px; }
    th, td { border-bottom: 1px solid #334155; padding: 6px 8px; text-align: left; }
    button { background: #2563eb; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; }
    button.danger { background: #dc2626; }
    input, select { background: #0f172a; color: #e2e8f0; border: 1px solid #475569; padding: 5px 8px; border-radius: 4px; }
    .badge { padding: 2px 8px; border-radius: 4px; background: #334155; font-size: 12px; }
    .sev-HIGH { background: #7f1d1d; color: #fecaca; padding: 2px 6px; border-radius: 3px; font-weight: 600; font-size: 11px; }
    .sev-MEDIUM { background: #78350f; color: #fde68a; padding: 2px 6px; border-radius: 3px; font-weight: 600; font-size: 11px; }
    .sev-LOW { background: #1e293b; color: #94a3b8; border: 1px solid #475569; padding: 2px 6px; border-radius: 3px; font-size: 11px; }
    .toolbar { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin-bottom: 8px; font-size: 13px; }
  </style>
</head>
<body>
<header>
  <div><strong>EO/IR Integrated Surveillance Console</strong> <span id="camBanner" class="badge"></span></div>
  <div>
    Active Sensor:
    <select id="activeCamSelect" onchange="loadFrame()"></select>
    &nbsp;|&nbsp;
    Role:
    <select id="roleSelect" onchange="onRoleChange()">
      <option value="viewer">viewer (Read-Only)</option>
      <option value="operator" selected>operator</option>
      <option value="admin">admin</option>
    </select>
    <button onclick="resetState()">Reset Demo Data</button>
  </div>
</header>

<div class="grid">
  <div class="card">
    <h3>Live EO/IR Feed & AI Detection Overlay</h3>
    <div class="toolbar">
      <button id="playBtn" onclick="togglePlay()">&#9654; Play</button>
      <button onclick="stepFrame(-1)">&#9664; Prev</button>
      <span>Frame: <strong id="frameLabel" class="badge">0</strong></span>
      <button onclick="stepFrame(1)">Next &#9654;</button>
      <span>|</span>
      <span>Conf Threshold: <input type="range" id="confSlider" min="0" max="1" step="0.05" value="0.50" oninput="loadFrame()"> <strong id="confVal">0.50</strong></span>
      <span>|</span>
      <button onclick="reconnectStream()">Simulate Stream Reconnect</button>
    </div>
    <canvas id="videoCanvas" width="600" height="300"></canvas>
    <p id="sceneDesc" style="font-size:12px;color:#94a3b8;margin:6px 0;"></p>
    <div style="font-size:12px;">
      <span style="color:#22c55e;">&#9632; Solid Green = True Target in Video Frame</span> &nbsp;&nbsp;
      <span style="color:#ef4444;">&#9633; Dashed Red = AI Overlay Bounding Box</span>
    </div>
  </div>

  <div class="card">
    <h3>Alerts & Geo-Map Projection</h3>
    <div class="toolbar" style="justify-content:space-between;">
      <div>
        <button onclick="triggerScan()">Run Alert Scan at Current Threshold</button>
      </div>
      <div>
        <button onclick="changePage(-1)">&#9664;</button>
        <span id="pageInfo" class="badge">Page 1</span>
        <button onclick="changePage(1)">&#9654;</button>
        Page Size:
        <select id="pageSize" onchange="currentPage=1; loadAlerts()">
          <option value="5" selected>5</option>
          <option value="10">10</option>
        </select>
      </div>
    </div>
    <div id="alertCountSummary" style="font-size:12px;color:#94a3b8;margin-bottom:4px;"></div>
    <table>
      <thead>
        <tr><th>ID</th><th>Track</th><th>Class</th><th>Conf</th><th>Severity</th><th>Geo Pin (Lat, Lon)</th><th>Action</th></tr>
      </thead>
      <tbody id="alertTable"></tbody>
    </table>

    <h4 style="margin-top:18px;margin-bottom:8px;">Add Camera Stream <span style="font-size:11px;color:#94a3b8;font-weight:normal;">(Admin Only, 1–120 FPS)</span></h4>
    <div class="toolbar">
      Name: <input id="camName" placeholder="e.g. IR-SOUTH-03">
      FPS: <input id="camFps" type="number" value="25" style="width:60px;">
      <button id="addCamBtn" onclick="addCamera()">Add Camera</button>
    </div>
  </div>
</div>

<script>
let currentFrame = 0;
let currentPage = 1;
let playTimer = null;

function getRole() {
  return document.getElementById('roleSelect').value;
}

function onRoleChange() {
  loadAlerts();
}

function togglePlay() {
  const btn = document.getElementById('playBtn');
  if (playTimer) {
    clearInterval(playTimer);
    playTimer = null;
    btn.innerHTML = '&#9654; Play';
  } else {
    btn.innerHTML = '&#9208; Pause';
    playTimer = setInterval(() => stepFrame(1), 900);
  }
}

function stepFrame(delta) {
  currentFrame = (currentFrame + delta + 4) % 4;
  loadFrame();
}

function changePage(delta) {
  currentPage = Math.max(1, currentPage + delta);
  loadAlerts();
}

function drawHudGrid(ctx, canvas, data) {
  ctx.strokeStyle = 'rgba(51, 65, 85, 0.45)';
  ctx.lineWidth = 1;
  for (let x = 100; x < canvas.width; x += 100) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke();
  }
  for (let y = 75; y < canvas.height; y += 75) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
  }
  const cx = canvas.width / 2, cy = canvas.height / 2;
  ctx.strokeStyle = 'rgba(148, 163, 184, 0.35)';
  ctx.beginPath();
  ctx.moveTo(cx - 18, cy); ctx.lineTo(cx + 18, cy);
  ctx.moveTo(cx, cy - 18); ctx.lineTo(cx, cy + 18);
  ctx.stroke();

  const camSel = document.getElementById('activeCamSelect');
  const camLabel = camSel && camSel.value ? camSel.value : 'EO-NORTH-01';
  const desync = data.video_pts_ms !== data.overlay_pts_ms;
  ctx.fillStyle = '#94a3b8';
  ctx.font = '11px monospace';
  ctx.fillText(`CAM: ${camLabel} | FRAME: ${data.frame_id} | RECONNECTS: ${data.reconnects || 0}`, 10, 16);
  ctx.fillStyle = desync ? '#f87171' : '#4ade80';
  ctx.fillText(
    `VIDEO PTS: ${data.video_pts_ms}ms | OVERLAY PTS: ${data.overlay_pts_ms}ms ${desync ? '[PTS DESYNC]' : '[SYNC OK]'}`,
    10, 290
  );
}

async function loadFrame() {
  const conf = document.getElementById('confSlider').value;
  document.getElementById('confVal').innerText = conf;
  document.getElementById('frameLabel').innerText = currentFrame;

  const canvas = document.getElementById('videoCanvas');
  const ctx = canvas.getContext('2d');
  try {
    const res = await fetch(`/api/frame_state?frame=${currentFrame}&min_conf=${conf}`);
    const data = await res.json();
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (!res.ok) {
      ctx.fillStyle = '#ef4444';
      ctx.font = '16px monospace';
      ctx.fillText('STREAM ERROR: ' + res.status + ' (' + (data.error || 'Server Error') + ')', 20, 150);
      return;
    }

    drawHudGrid(ctx, canvas, data);

    document.getElementById('sceneDesc').innerText =
      `Video PTS: ${data.video_pts_ms} ms | Overlay PTS: ${data.overlay_pts_ms} ms | ${data.scene_desc}`;

    for (const gt of data.ground_truth_positions) {
      ctx.fillStyle = 'rgba(34, 197, 94, 0.30)';
      ctx.fillRect(gt.x, gt.y, gt.w, gt.h);
      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 2;
      ctx.strokeRect(gt.x, gt.y, gt.w, gt.h);
      ctx.fillStyle = '#86efac';
      ctx.font = '11px sans-serif';
      ctx.fillText(gt.label, gt.x, gt.y - 4);
    }

    ctx.setLineDash([5, 3]);
    for (const d of data.overlays) {
      const [x1, y1, x2, y2] = d.bbox;
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 2;
      ctx.strokeRect(x1, y1, x2 - x1, y2 - y1);
      ctx.fillStyle = '#fca5a5';
      ctx.fillText(`${d.track_id} ${d.class} (${d.conf})`, x1, y2 + 13);
    }
    ctx.setLineDash([]);
  } catch (err) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#ef4444';
    ctx.font = '16px monospace';
    ctx.fillText('STREAM ERROR: Connection Failure', 20, 150);
  }
}

async function loadAlerts() {
  const limit = parseInt(document.getElementById('pageSize').value, 10);
  const role = getRole();
  const res = await fetch(`/api/alerts?page=${currentPage}&limit=${limit}`, { headers: { 'X-Role': role } });
  const data = await res.json();
  const maxPage = Math.max(1, Math.ceil((data.total || 0) / limit));
  if (currentPage > maxPage) {
    currentPage = maxPage;
    return loadAlerts();
  }
  document.getElementById('pageInfo').innerText = `Page ${data.page} / ${maxPage}`;
  document.getElementById('alertCountSummary').innerText =
    `Showing ${data.alerts.length} of ${data.total} total alerts (page=${data.page}, limit=${data.limit})`;

  const tbody = document.getElementById('alertTable');
  tbody.innerHTML = '';
  for (const a of data.alerts) {
    let actionHtml = '';
    if (role === 'viewer') {
      actionHtml = '<span style="color:#64748b;">Read-only</span>';
    } else if (role === 'operator' && a.severity === 'HIGH') {
      actionHtml = '<span style="color:#64748b; font-size:11px;">Restricted</span>';
    } else {
      actionHtml = `<button class="danger" onclick="deleteAlert(${a.id})">Delete</button>`;
    }
    tbody.innerHTML += `<tr>
      <td>${a.id}</td>
      <td>${a.track_id}</td>
      <td>${a.class}</td>
      <td>${a.conf}</td>
      <td><span class="sev-${a.severity}">${a.severity}</span></td>
      <td>${Number(a.lat).toFixed(4)}, ${Number(a.lon).toFixed(4)}</td>
      <td>${actionHtml}</td>
    </tr>`;
  }
}

async function deleteAlert(id) {
  const res = await fetch(`/api/alerts/${id}`, { method: 'DELETE', headers: { 'X-Role': getRole() } });
  if (res.status === 403) {
    alert("Permission denied: You are not authorized to delete this alert.");
  }
  loadAlerts();
}

async function triggerScan() {
  const conf = document.getElementById('confSlider').value;
  await fetch('/api/trigger_scan', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Role': getRole() },
    body: JSON.stringify({ frame_id: currentFrame, min_conf: parseFloat(conf) })
  });
  loadAlerts();
}

async function reconnectStream() {
  await fetch('/api/stream/reconnect', { method: 'POST' });
  loadFrame();
  loadAlerts();
}

async function loadCameras() {
  const res = await fetch('/api/cameras');
  const data = await res.json();
  const safeHtml = data.cameras.map(c => {
    const div = document.createElement('div');
    div.textContent = `${c.name} (${c.fps} FPS)`;
    return div.innerHTML;
  }).join(' | ');
  document.getElementById('camBanner').innerHTML = 'Active Cameras: ' + safeHtml;
  const sel = document.getElementById('activeCamSelect');
  const prev = sel.value;
  sel.innerHTML = data.cameras.map(c => `<option value="${c.id}">${c.id} — ${c.name}</option>`).join('');
  if (prev) sel.value = prev;
}

async function addCamera() {
  const name = document.getElementById('camName').value.trim();
  const fps = parseInt(document.getElementById('camFps').value || '0', 10);
  if (!name) {
    alert("Camera name cannot be empty.");
    return;
  }
  const res = await fetch('/api/cameras', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Role': getRole() },
    body: JSON.stringify({ name, fps })
  });
  if (res.status === 403) {
    alert("Access Denied: Only Admin can add cameras.");
    return;
  }
  if (!res.ok) {
    const data = await res.json();
    alert("Error: " + (data.error || "Failed to add camera"));
    return;
  }
  document.getElementById('camName').value = '';
  loadCameras();
}

async function resetState() {
  if (playTimer) togglePlay();
  currentFrame = 0;
  currentPage = 1;
  await fetch('/api/reset', { method: 'POST' });
  loadCameras();
  loadFrame();
  loadAlerts();
}

loadCameras();
loadFrame();
loadAlerts();
</script>
</body>
</html>
"""


class ConsoleHandler(BaseHTTPRequestHandler):
    def _send(self, code, payload, content_type="application/json"):
        body = payload.encode("utf-8") if isinstance(payload, str) else json.dumps(payload).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length == 0:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(parsed.query)

        if parsed.path == "/":
            self._send(200, HTML_PAGE, content_type="text/html; charset=utf-8")
            return

        # ICD-1.1 & ICD-1.2: Exact time sync and inclusive confidence filtering
        if parsed.path == "/api/frame_state":
            try:
                frame_param = qs.get("frame_id", qs.get("frame", ["0"]))[0]
                frame_idx = int(frame_param) % len(FRAMES)
                min_conf = float(qs.get("min_conf", ["0.5"])[0])

                video_frame = FRAMES[frame_idx]
                overlay_frame = video_frame  # 0 ms temporal drift

                overlays = [d for d in overlay_frame["detections"] if d["conf"] >= min_conf]

                self._send(200, {
                    "frame_id": video_frame["frame_id"],
                    "video_pts_ms": video_frame["pts_ms"],
                    "overlay_pts_ms": overlay_frame["pts_ms"],
                    "reconnects": STATE["stream_reconnects"],
                    "scene_desc": video_frame["scene_desc"],
                    "ground_truth_positions": video_frame["ground_truth_positions"],
                    "overlays": overlays,
                })
            except Exception as exc:
                self._send(500, {"error": f"{type(exc).__name__}: {exc}"})
            return

        # ICD-2.1 & ICD-2.3: Standard WGS-84 coordinate ordering and exact slice pagination
        if parsed.path == "/api/alerts":
            page = max(1, int(qs.get("page", ["1"])[0]))
            limit = max(1, int(qs.get("limit", ["5"])[0]))
            start = (page - 1) * limit
            end = start + limit
            sliced = STATE["alerts"][start:end]

            out = []
            for a in sliced:
                out.append({
                    "id": a["id"],
                    "track_id": a["track_id"],
                    "frame_id": a["frame_id"],
                    "class": a["class"],
                    "conf": a["conf"],
                    "lat": a["lat"],  # Preserves unswapped latitude
                    "lon": a["lon"],  # Preserves unswapped longitude
                    "severity": a["severity"],
                })
            self._send(200, {"total": len(STATE["alerts"]), "page": page, "limit": limit, "alerts": out})
            return

        if parsed.path == "/api/cameras":
            self._send(200, {"cameras": STATE["cameras"]})
            return

        self._send(404, {"error": "not found"})

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        role = self.headers.get("X-Role", "viewer")

        if parsed.path == "/api/login":
            body = self._read_json()
            u = USERS.get(body.get("username", ""))
            if not u or u["password"] != body.get("password"):
                self._send(401, {"error": "invalid credentials"})
                return
            self._send(200, {"username": body["username"], "role": u["role"], "token": f"tok-{u['role']}"})
            return

        # ICD-2.2: Threshold-gated alert generation and tier categorization
        if parsed.path == "/api/trigger_scan":
            body = self._read_json()
            frame_idx = int(body.get("frame_id", 0)) % len(FRAMES)
            min_conf = float(body.get("min_conf", 0.0))
            next_id = max([a["id"] for a in STATE["alerts"]] or [0]) + 1
            created = []
            for d in FRAMES[frame_idx]["detections"]:
                if d["conf"] >= min_conf:
                    if d["conf"] >= 0.85:
                        sev = "HIGH"
                    elif d["conf"] >= 0.50:
                        sev = "MEDIUM"
                    else:
                        sev = "LOW"

                    rec = {
                        "id": next_id,
                        "track_id": d["track_id"],
                        "frame_id": frame_idx,
                        "class": d["class"],
                        "conf": d["conf"],
                        "lat": d["lat"],
                        "lon": d["lon"],
                        "severity": sev,
                    }
                    STATE["alerts"].append(rec)
                    created.append(rec)
                    next_id += 1
            self._send(201, {"created": len(created), "alerts": created})
            return

        # ICD-2.4: Stream reconnect idempotency (no duplicate alert records)
        if parsed.path == "/api/stream/reconnect":
            STATE["stream_reconnects"] += 1
            self._send(200, {"status": "reconnected", "reconnect_count": STATE["stream_reconnects"]})
            return

        # ICD-3.1 & ICD-3.2: Admin-only RBAC, FPS boundaries (1–120), and input sanitization
        if parsed.path == "/api/cameras":
            if role != "admin":
                self._send(403, {"error": "forbidden: admin role required"})
                return

            body = self._read_json()
            name = str(body.get("name", "")).strip()
            fps = body.get("fps")

            if not name:
                self._send(400, {"error": "camera name cannot be empty"})
                return

            if not isinstance(fps, int) or fps < 1 or fps > 120:
                self._send(400, {"error": "invalid FPS: must be an integer between 1 and 120"})
                return

            cam = {
                "id": f"CAM-{len(STATE['cameras']) + 1:02d}",
                "name": html.escape(name),
                "fps": fps,
                "status": "ONLINE",
            }
            STATE["cameras"].append(cam)
            self._send(201, cam)
            return

        if parsed.path == "/api/reset":
            STATE["alerts"] = copy.deepcopy(INITIAL_ALERTS)
            STATE["cameras"] = [
                {"id": "EO-NORTH-01", "name": "Sector-4 Thermal PTZ", "fps": 25, "status": "ONLINE"},
                {"id": "IR-EAST-02",  "name": "Perimeter IR Fixed",   "fps": 25, "status": "ONLINE"},
            ]
            STATE["stream_reconnects"] = 0
            self._send(200, {"status": "reset"})
            return

        self._send(404, {"error": "not found"})

    # ICD-3.1: Tiered deletion permissions across roles
    def do_DELETE(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path.startswith("/api/alerts/"):
            role = self.headers.get("X-Role", "viewer")

            if role == "viewer":
                self._send(403, {"error": "forbidden: viewer cannot delete alerts"})
                return

            try:
                alert_id = int(parsed.path.split("/")[-1])
            except ValueError:
                self._send(400, {"error": "invalid alert ID"})
                return

            target = next((a for a in STATE["alerts"] if a["id"] == alert_id), None)
            if not target:
                self._send(404, {"error": "alert not found"})
                return

            if role == "operator" and target.get("severity") == "HIGH":
                self._send(403, {"error": "forbidden: operator cannot delete HIGH severity alerts"})
                return

            STATE["alerts"] = [a for a in STATE["alerts"] if a["id"] != alert_id]
            self._send(200, {"deleted": alert_id})
            return

        self._send(404, {"error": "not found"})


if __name__ == "__main__":
    print(f"EO/IR Operator Console running at http://localhost:{PORT}")
    HTTPServer(("0.0.0.0", PORT), ConsoleHandler).serve_forever()