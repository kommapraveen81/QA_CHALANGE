# EO/IR Surveillance & Operator Console — QA Submission & Verification Package

This test suite qualifies the release candidate of `app.py` against **ICD-1.1 through ICD-3.2** subsystem specifications.

## ⚡ Single-Command Quick Execution

You can run the entire regression suite, generate the self-contained HTML execution report, and produce terminal test metrics with a single command:

### Windows (PowerShell)

```
python -m pytest --html=reports/test_report.html --self-contained-html -v

```

### Linux / macOS (Bash)

```
python3 -m pytest --html=reports/test_report.html --self-contained-html -v

```

> **Note:** The server lifecycle is managed automatically by `tests/conftest.py`. It binds to an ephemeral OS port, boots up in an isolated daemon thread, executes all tests, and shuts down cleanly upon completion. You do **not** need to manually start `python app.py` before running tests.

## 📋 Environment Setup & Prerequisites

### 1. Requirements

* Python 3.8+

* Pip package manager

### 2. Quick Setup (Virtual Environment)

#### On Windows:

```
# Create virtual environment
python -m venv .venv

# Activate virtual environment
.\.venv\Scripts\Activate.ps1

# Install test framework and report dependencies
python -m pip install -r requirements.txt

```

*(If PowerShell restricts script execution, run: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`)*

#### On Linux / macOS:

```
# Create virtual environment
python3 -m venv .venv

# Activate virtual environment
source .venv/bin/activate

# Install test framework and report dependencies
python3 -m pip install -r requirements.txt

```

### 3. (Optional) Playwright Browser Binaries

If you are running the browser-level UI test suite (`tests/test_ui_e2e.py`):

```
python -m playwright install chromium

```

## 🧪 Targeted Test Execution Commands

| Target Scope | Command | Description | 
| ----- | ----- | ----- | 
| **Complete Suite** | `python -m pytest -v` | Runs both API (`test_api_icd.py`) and UI (`test_ui_e2e.py`) suites | 
| **REST API Qualification** | `python -m pytest tests/test_api_icd.py -v` | Asserts ICD-1.1 through ICD-3.2 against backend endpoints | 
| **Browser UI / E2E** | `python -m pytest tests/test_ui_e2e.py -v` | Headless Chromium tests validating HUD canvas, stepping, and RBAC table | 
| **Interactive Headed UI** | `python -m pytest tests/test_ui_e2e.py --headed` | Launches visible browser window to visually observe test execution | 
| **HTML Report Generation** | `python -m pytest --html=reports/test_report.html --self-contained-html -v` | Builds portable, single-file HTML report in `reports/test_report.html` | 
| **Zero-Dependency Runner** | `python -m unittest test_challenge.py -v` | Runs standard-library-only test suite (zero pip packages required) | 

## 🔍 Proving Defect Detection (Negative Testing)

The test suite is built to catch the real defects documented in `BUG_REPORT.md`:

1. **Test Against Unfixed/Original `app.py`:**
   Run:

   ```
   python -m pytest tests/test_api_icd.py -v
   
   ```

   **Observed Result:** 12 tests fail immediately, pinpointing:

   * ICD-1.1 Telemetry Drift (Frame 1 PTS: 1040 ms vs 1120 ms)

   * ICD-1.2 ZeroDivisionError at `min_conf=1.0`

   * ICD-1.2 Strict inequality drops (`conf == min_conf`)

   * ICD-2.1 Inverted Lat/Lon coordinates (`lat: 77.209, lon: 28.6139`)

   * ICD-2.3 Off-by-one pagination slice (returns 4 instead of 5 items)

   * ICD-2.4 Reconnect duplicate records (`total` jumps from 5 to 10)

   * ICD-3.1 Viewer delete privilege escalation (HTTP 200 instead of 403)

   * ICD-3.1 Operator HIGH severity alert deletion

   * ICD-3.1 Non-admin camera provisioning

   * ICD-3.2 Negative/out-of-range camera FPS acceptance

2. **Test Against Patched `app.py`:**
   Run:

   ```
   python -m pytest tests/test_api_icd.py -v
   
   ```

   **Observed Result:** All 12 tests pass cleanly in under 2 seconds.

## 📁 Repository Structure

```
├── BUG_REPORT.md             # Task 1 Defect Analysis & Task 3 Golden Checklist (Markdown)
├── README_SUBMISSION.md      # Setup, architecture, and single-command instructions
├── requirements.txt          # Python dependencies (pytest, pytest-html, playwright)
├── app.py                    # Candidate / Patched EO/IR Console application
└── tests/
    ├── conftest.py           # Ephemeral port binding & state reset fixtures
    ├── test_api_icd.py       # REST API qualification suite (ICD-1.1 - ICD-3.2)
    └── test_ui_e2e.py        # Playwright E2E browser tests (Canvas HUD, UI RBAC)

```