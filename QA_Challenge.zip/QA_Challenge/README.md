# Software Tester / QA Engineer Challenge — EO/IR Operator Console Validation

**Timebox:** 48 hours  
**Runs on:** Any laptop with Python 3.8+ (zero external packages required to start the app — uses Python standard library).

```bash
python app.py
# Open http://localhost:8080 in your browser
```

---

## Scenario & Interface Control Document (ICD)

You are the QA Engineer qualifying a release candidate of the **EO/IR Integrated Surveillance Console** (`app.py`) before promotion to a defence site. The console must conform to the following subsystem specifications:

1. **Live EO/IR Video & Detection Overlay (`GET /api/frame_state`):**
   - **ICD-1.1 (Frame & Telemetry Time Sync):** Across all frames (`0..3`), continuous playback, and stream reconnect events, AI detection overlay bounding boxes and `overlay_pts_ms` **must match the exact `frame_id` and `video_pts_ms`** being displayed (`0 ms` drift).
   - **ICD-1.2 (Confidence Thresholding):** Detections with `conf >= min_conf` (inclusive boundary across the full `0.00` to `1.00` slider/query range) must be returned and rendered without server or stream errors.
2. **Alerts, Severity Classification & Geo-Map Projection (`GET /api/alerts`, `POST /api/trigger_scan`, `POST /api/stream/reconnect`):**
   - **ICD-2.1 (WGS-84 Geo Coordinates):** Site sensors operate in northern India (`latitude ~ 28.61° N`, `longitude ~ 77.21° E`). Alert coordinates must be serialized and displayed in standard `(lat, lon)` order.
   - **ICD-2.2 (Threshold-Gated Alert Scans & Severity Tiers):** Triggering an Alert Scan (`POST /api/trigger_scan`) must only generate alerts for detections with `conf >= min_conf`, and must assign severity tiers as:
     - `HIGH`: `conf >= 0.85`
     - `MEDIUM`: `0.50 <= conf < 0.85`
     - `LOW`: `conf < 0.50`
   - **ICD-2.3 (Pagination Integrity):** `GET /api/alerts?page=P&limit=N` must return up to `N` alerts per page with no missing or skipped records across pages, matching `total`.
   - **ICD-2.4 (Stream Reconnect Idempotency):** Stream reconnect events (`POST /api/stream/reconnect`) must not duplicate existing alerts for already-logged `(track_id, frame_id)` detections.
3. **Role-Based Access Control & Sensor Provisioning (`DELETE /api/alerts/<id>`, `POST /api/cameras`):**
   - **ICD-3.1 (Tiered RBAC):**
     - `viewer`: strictly read-only (`403 Forbidden` on all mutating endpoints).
     - `operator`: may delete `LOW` and `MEDIUM` severity alerts, but **must not** delete `HIGH` severity alerts (`403 Forbidden`) or provision cameras.
     - `admin`: full access to delete any alert and provision new camera streams.
   - **ICD-3.2 (Camera Input Validation & Sanitization):** `POST /api/cameras` must reject empty names, `fps < 1` or `fps > 120`, and must sanitize/reject HTML or script payloads.

---

## Tasks

### Task 1 — Exploratory, Boundary & Sync Defect Report (`BUG_REPORT.md`)
Qualify the console across both the browser UI and REST API against `ICD-1.1` through `ICD-3.2`.
- Document every defect you uncover in `BUG_REPORT.md` with:
  - **Bug ID & Title**, **ICD requirement violated**, **Severity** (`Critical` / `High` / `Medium` / `Low`),
  - **Exact reproduction steps** (UI interaction sequence and/or `curl` request),
  - **Expected vs. Actual result**, and **Root-cause analysis** (with response payload or screenshot).

### Task 2 — Automated Regression Suite (`tests/`)
Write an automated test suite (using **Playwright** or **Selenium** for UI + `pytest` / `requests` for REST API) that asserts the ICD requirements above and **fails against the unfixed `app.py`** (proving your tests catch the real defects).
- Include `requirements.txt` and single-command execution instructions in `README_SUBMISSION.md`.

### Task 3 — Golden-Scenario Release Checklist (half page in `BUG_REPORT.md`)
Briefly outline what **golden clip / negative-test checks** you would run on site before signing off a new AI detector `.engine` + operator console release.

---

## Submission

Reply with a link (OneDrive / Google Drive / private GitHub repo) containing:
1. `BUG_REPORT.md`, your `tests/` directory, `requirements.txt`, and `README_SUBMISSION.md`.
2. Be prepared to **demo your findings and run your automated test suite live** during your review session.
