"""
tests/test_ui_e2e.py - End-to-End Playwright UI tests for the EO/IR Console.
Validates Canvas HUD, Play/Pause, Frame Stepping, Sliders, and RBAC visibility.
"""
import pytest
from playwright.sync_api import Page, expect


def test_ui_canvas_and_hud_load(page: Page, base_url: str):
    """Checks that the video canvas loads and renders initial HUD text."""
    page.goto(base_url)
    canvas = page.locator("#videoCanvas")
    expect(canvas).to_be_visible()

    # Frame label starts at 0
    frame_label = page.locator("#frameLabel")
    expect(frame_label).to_have_text("0")

    # Initial scene description must be loaded and show sync status
    scene_desc = page.locator("#sceneDesc")
    expect(scene_desc).to_contain_text("Video PTS: 1000 ms")
    expect(scene_desc).to_contain_text("Overlay PTS: 1000 ms")


def test_ui_frame_stepping_maintains_pts_sync(page: Page, base_url: str):
    """ICD-1.1: Stepping to next frames must update HUD and show zero PTS drift."""
    page.goto(base_url)

    # Click 'Next ▶' button
    page.locator("button:has-text('Next')").click()
    page.wait_for_timeout(200)

    # Frame counter increments to 1
    expect(page.locator("#frameLabel")).to_have_text("1")

    # Frame 1 PTS is 1040 ms for both video and overlay
    scene_desc = page.locator("#sceneDesc")
    expect(scene_desc).to_contain_text("Video PTS: 1040 ms")
    expect(scene_desc).to_contain_text("Overlay PTS: 1040 ms")


def test_ui_confidence_slider_ceiling_no_crash(page: Page, base_url: str):
    """ICD-1.2: Moving slider to 1.00 must not crash the stream with a 500 error."""
    page.goto(base_url)

    # Set slider to 1.00 via JS event
    page.eval_on_selector(
        "#confSlider",
        """el => {
            el.value = '1';
            el.dispatchEvent(new Event('input', { bubbles: true }));
        }"""
    )
    page.wait_for_timeout(300)

    # Confidence value label updates to 1
    expect(page.locator("#confVal")).to_have_text("1")

    # Verify no stream error text is printed on the canvas or scene text
    scene_desc = page.locator("#sceneDesc").inner_text()
    assert "STREAM ERROR" not in scene_desc


def test_ui_alerts_table_pagination_and_coordinates(page: Page, base_url: str):
    """ICD-2.1 & 2.3: Table shows 5 items on Page 1 and lat/lon are not inverted."""
    page.goto(base_url)

    # Alert rows must equal 5 on initial load
    rows = page.locator("#alertTable tr")
    expect(rows).to_have_count(5)

    # First row coordinates must be around Lat: 28.6139, Lon: 77.2090
    first_row_geo = rows.first.locator("td").nth(5).inner_text()
    lat, lon = [float(x.strip()) for x in first_row_geo.split(",")]
    assert 20.0 <= lat <= 35.0, f"Latitude was inverted: {lat}"
    assert 70.0 <= lon <= 85.0, f"Longitude was inverted: {lon}"


def test_ui_role_change_to_viewer_enforces_read_only(page: Page, base_url: str):
    """ICD-3.1: Switching role to viewer hides delete buttons and shows Read-only."""
    page.goto(base_url)

    # Switch dropdown to viewer
    page.select_option("#roleSelect", "viewer")
    page.wait_for_timeout(250)

    # Danger/Delete buttons must no longer exist in the alerts table
    delete_buttons = page.locator("#alertTable button.danger")
    expect(delete_buttons).to_have_count(0)

    # Read-only text badges appear
    read_only_labels = page.locator("#alertTable span:has-text('Read-only')")
    expect(read_only_labels).to_have_count(5)


def test_ui_operator_cannot_delete_high_severity_alert(page: Page, base_url: str):
    """ICD-3.1: Operator role displays 'Restricted' for HIGH severity alerts."""
    page.goto(base_url)

    # Select operator
    page.select_option("#roleSelect", "operator")
    page.wait_for_timeout(250)

    # Alert 1 is HIGH severity: action column must display 'Restricted'
    first_row_action = page.locator("#alertTable tr").first.locator("td").nth(6)
    expect(first_row_action).to_contain_text("Restricted")

    # Alert 2 is LOW severity: action column must display an active Delete button
    second_row_action = page.locator("#alertTable tr").nth(1).locator("td").nth(6)
    expect(second_row_action.locator("button.danger")).to_be_visible()