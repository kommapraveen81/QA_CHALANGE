"""
tests/conftest.py - Pytest fixtures and server lifecycle management.
Runs the HTTP server on an ephemeral free port for the test session.
"""
from http.server import HTTPServer
import threading
import time
import urllib.request
import pytest

from app import ConsoleHandler


@pytest.fixture(scope="session")
def base_url():
    """Starts the application server on an OS-assigned ephemeral port (0)."""
    server = HTTPServer(("127.0.0.1", 0), ConsoleHandler)
    port = server.server_port
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()

    time.sleep(0.2)  # Give the server thread a moment to bind and listen
    url = f"http://127.0.0.1:{port}"
    yield url

    server.shutdown()
    server.server_close()


@pytest.fixture(autouse=True)
def reset_server_state(base_url):
    """Resets the server data back to baseline before every individual test."""
    req = urllib.request.Request(f"{base_url}/api/reset", data=b"{}", method="POST")
    with urllib.request.urlopen(req) as resp:
        assert resp.status == 200