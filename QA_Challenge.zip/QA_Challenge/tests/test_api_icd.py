"""
Automated REST API Qualification Suite asserting ICD-1.1 through ICD-3.2.
Uses Python standard library (urllib) - zero external pip dependencies required.
"""
from http.server import HTTPServer
import json
import threading
import time
import urllib.request
import urllib.error
import pytest

from app import ConsoleHandler, STATE, INITIAL_ALERTS


class APIClient:
    """Helper client using Python standard library urllib."""
    def __init__(self, base_url):
        self.base_url = base_url

    def request(self, method, path, json_data=None, headers=None):
        url = f"{self.base_url}{path}"
        req_headers = headers.copy() if headers else {}
        data = None
        if json_data is not None:
            data = json.dumps(json_data).encode("utf-8")
            req_headers["Content-Type"] = "application/json"

        req = urllib.request.Request(url, data=data, headers=req_headers, method=method)
        try:
            with urllib.request.urlopen(req) as resp:
                status = resp.status
                body = resp.read().decode("utf-8")
                return status, json.loads(body) if body else {}
        except urllib.error.HTTPError as exc:
            status = exc.code
            body = exc.read().decode("utf-8")
            try:
                parsed = json.loads(body)
            except Exception:
                parsed = {"raw": body}
            return status, parsed


@pytest.fixture(scope="session")
def api():
    """Starts the application server on an ephemeral OS-assigned port."""
    server = HTTPServer(("127.0.0.1", 0), ConsoleHandler)
    port = server.server_port
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()
    time.sleep(0.15)
    client = APIClient(f"http://127.0.0.1:{port}")
    yield client
    server.shutdown()
    server.server_close()


@pytest.fixture(autouse=True)
def reset_server_state(api):
    """Resets server state prior to each test run."""
    status, _ = api.request("POST", "/api/reset")
    assert status == 200


def test_icd_1_1_pts_synchronization_under_playback(api):
    """ICD-1.1: Overlay PTS must match Video PTS exactly (0 ms drift) across all frames."""
    for frame_id in range(4):
        status, data = api.request("GET", f"/api/frame_state?frame={frame_id}")
        assert status == 200
        assert data["video_pts_ms"] == data["overlay_pts_ms"], (
            f"ICD-1.1 Violation: Drift detected at frame {frame_id}. "
            f"Video PTS={data['video_pts_ms']}, Overlay PTS={data['overlay_pts_ms']}"
        )


def test_icd_1_1_pts_synchronization_after_reconnect(api):
    """ICD-1.1: Overlay PTS must not drift after stream reconnection."""
    api.request("POST", "/api/stream/reconnect")
    status, data = api.request("GET", "/api/frame_state?frame=1")
    assert status == 200
    assert data["video_pts_ms"] == data["overlay_pts_ms"], (
        f"ICD-1.1 Violation: Drift post-reconnect. Video={data['video_pts_ms']}, Overlay={data['overlay_pts_ms']}"
    )


def test_icd_1_2_confidence_threshold_ceiling(api):
    """ICD-1.2: Threshold of 1.00 must not crash the server with ZeroDivisionError."""
    status, data = api.request("GET", "/api/frame_state?frame=0&min_conf=1.0")
    assert status == 200, f"ICD-1.2 Violation: Expected 200, got {status} ({data})"
    assert len(data.get("overlays", [])) == 0


def test_icd_1_2_confidence_inclusive_boundary(api):
    """ICD-1.2: Detections with conf == min_conf must be returned (inclusive filter)."""
    status, data = api.request("GET", "/api/frame_state?frame=0&min_conf=0.92")
    assert status == 200
    track_ids = [d["track_id"] for d in data.get("overlays", [])]
    assert "TRK-101" in track_ids, "ICD-1.2 Violation: conf == min_conf was excluded"


def test_icd_2_1_wgs84_coordinates_order(api):
    """ICD-2.1: Geo pins must be in (lat, lon) order within Northern India bounds."""
    status, data = api.request("GET", "/api/alerts?page=1&limit=5")
    assert status == 200
    alerts = data.get("alerts", [])
    alert1 = next(a for a in alerts if a["id"] == 1)

    assert 20.0 <= alert1["lat"] <= 35.0, f"ICD-2.1 Violation: Latitude out of range: {alert1['lat']}"
    assert 70.0 <= alert1["lon"] <= 85.0, f"ICD-2.1 Violation: Longitude out of range: {alert1['lon']}"


def test_icd_2_2_alert_scan_severity_and_threshold(api):
    """ICD-2.2: Alert scans must filter by min_conf and categorize severities correctly."""
    status, data = api.request("POST", "/api/trigger_scan", json_data={"frame_id": 0, "min_conf": 0.50})
    assert status == 201
    created = data.get("alerts", [])
    assert len(created) == 1
    assert created[0]["track_id"] == "TRK-101"
    assert created[0]["severity"] == "HIGH"


def test_icd_2_3_pagination_exact_slice(api):
    """ICD-2.3: Pagination must return up to limit items without off-by-one drops."""
    status, data = api.request("GET", "/api/alerts?page=1&limit=5")
    assert status == 200
    assert data["total"] == 5
    alerts = data.get("alerts", [])
    assert len(alerts) == 5, f"ICD-2.3 Violation: Expected 5 items on page 1, got {len(alerts)}"


def test_icd_2_4_reconnect_idempotency(api):
    """ICD-2.4: Stream reconnect must not duplicate existing alert records."""
    _, initial_res = api.request("GET", "/api/alerts?page=1&limit=20")
    initial_count = initial_res["total"]

    api.request("POST", "/api/stream/reconnect")

    _, post_res = api.request("GET", "/api/alerts?page=1&limit=20")
    assert post_res["total"] == initial_count, (
        f"ICD-2.4 Violation: Stream reconnect inflated alerts from {initial_count} to {post_res['total']}"
    )


def test_icd_3_1_viewer_cannot_delete_any_alert(api):
    """ICD-3.1: Viewer role must receive 403 when deleting any alert."""
    for alert_id in [1, 2]:
        status, _ = api.request("DELETE", f"/api/alerts/{alert_id}", headers={"X-Role": "viewer"})
        assert status == 403, f"ICD-3.1 Violation: Viewer deleted alert {alert_id} (HTTP {status})"


def test_icd_3_1_operator_privilege_boundaries(api):
    """ICD-3.1: Operator can delete LOW/MEDIUM alerts, but cannot delete HIGH alerts."""
    status_high, _ = api.request("DELETE", "/api/alerts/1", headers={"X-Role": "operator"})
    assert status_high == 403, "ICD-3.1 Violation: Operator deleted HIGH severity alert"

    status_low, _ = api.request("DELETE", "/api/alerts/2", headers={"X-Role": "operator"})
    assert status_low == 200


def test_icd_3_1_admin_only_sensor_provisioning(api):
    """ICD-3.1: Only admin may provision new camera streams."""
    payload = {"name": "FLIR-SECTOR-EAST", "fps": 30}
    status_viewer, _ = api.request("POST", "/api/cameras", json_data=payload, headers={"X-Role": "viewer"})
    assert status_viewer == 403

    status_op, _ = api.request("POST", "/api/cameras", json_data=payload, headers={"X-Role": "operator"})
    assert status_op == 403

    status_admin, _ = api.request("POST", "/api/cameras", json_data=payload, headers={"X-Role": "admin"})
    assert status_admin == 201


def test_icd_3_2_camera_fps_validation_and_sanitization(api):
    """ICD-3.2: Rejects FPS outside 1–120 and accepts valid values."""
    headers = {"X-Role": "admin"}

    for invalid_fps in [-10, 0, 121, 500]:
        status, _ = api.request(
            "POST",
            "/api/cameras",
            json_data={"name": "CAM-TEST", "fps": invalid_fps},
            headers=headers
        )
        assert status == 400, f"ICD-3.2 Violation: Accepted invalid FPS {invalid_fps}"

    status_valid, _ = api.request(
        "POST",
        "/api/cameras",
        json_data={"name": "CAM-BOUND", "fps": 120},
        headers=headers
    )
    assert status_valid == 201