SOFTWARE QUALIFICATION & DEFECT VERIFICATION REPORT

Target System:        EO/IR Surveillance & Command Operator Console (app.py)

Qualification Standard: System Interface Control Document (ICD-1.1 - ICD-3.2)

Test Environment:     Python 3.8+ / Edge / Chrome / Linux / Windows

Evaluation Role:      Lead Embedded & Software Quality Assurance Engineer

Disposition:          REJECTED (Release Candidate Blocked)


1. EXECUTIVE SUMMARY & DEFECT MATRIX

During release candidate qualification testing against ICD-1.1 through ICD-3.2

specifications, 8 critical and high-severity defects were discovered in the

baseline app.py service. The defects span temporal telemetry desynchronization,

unhandled arithmetic division-by-zero crashes, transposed WGS-84 coordinate

geometry, off-by-one pagination truncation, non-idempotent state mutations,

and fundamental Role-Based Access Control (RBAC) privilege escalations.



Defect Summary Table:


ID       ICD Rule     Severity   Description

--------------------------------------------------------------------------------

BUG-01   ICD-1.1      Critical   80 ms (2-frame) overlay telemetry desync drift

BUG-02   ICD-1.2      High       ZeroDivisionError crash when min_conf = 1.00

BUG-03   ICD-1.2      Medium     Strict (>) inequality excludes boundary detections

BUG-04   ICD-2.1      Critical   Transposed WGS-84 coordinates (Lat/Lon swapped)

BUG-05   ICD-2.3      Medium     Off-by-one pagination slice drops last record

BUG-06   ICD-2.4      High       Reconnect event generates duplicate alert tracks

BUG-07   ICD-3.1      Critical   Viewer role permitted to delete active alerts

BUG-08   ICD-3.1/3.2  High       Operator adds cameras; invalid FPS/XSS accepted







2. IN-DEPTH DEFECT LOGS


BUG-01: AI Detection Overlay Telemetry & PTS Desynchronization



ICD Requirement Violated:

  ICD-1.1 (Frame & Telemetry Time Sync)



Severity:

  Critical



Subsystem:

  Video Frame Processing (GET /api/frame_state)



Steps to Reproduce:

  1. Start the operator console server:

     python app.py

  2. Send an HTTP GET request querying frame index 1:

     curl -s "http://localhost:8080/api/frame_state?frame=1"

  3. Inspect video_pts_ms vs overlay_pts_ms and bounding box coordinates.



Expected Result:

  Per ICD-1.1, overlay_pts_ms must equal video_pts_ms (1040 ms, 0 ms drift).

  Overlay bounding box for TRK-101 must match ground truth vehicle coordinates

  at [150, 140, 240, 185].



Actual Result:

  Response payload:

  {

    "frame_id": 1,

    "video_pts_ms": 1040,

    "overlay_pts_ms": 1120,

    "reconnects": 0,

    "overlays": [

      {

        "track_id": "TRK-101",

        "class": "vehicle",

        "conf": 0.91,

        "bbox": [310, 140, 400, 185]

      }

    ]

  }

  The overlay is fetched from Frame 3 (+80 ms / 2 frames ahead). The operator

  HUD renders [PTS DESYNC] in red, displaying leading ghost boxes disconnected

  from real video targets.



Root-Cause Analysis:

  In app.py lines inside do_GET:

    drift_frames = 2 if (frame_idx >= 1 or STATE["stream_reconnects"] > 0) else 0

    overlay_frame = FRAMES[(frame_idx + drift_frames) % len(FRAMES)]

  An artificial offset (drift_frames = 2) decouples detection bounding boxes

  from the current video timestamp.


BUG-02: ZeroDivisionError Server Crash on Upper Confidence Ceiling


ICD Requirement Violated:

  ICD-1.2 (Confidence Thresholding)



Severity:

  High



Subsystem:

  Detection Ingestion Pipeline (GET /api/frame_state)



Steps to Reproduce:

  1. Query frame_state setting min_conf to 1.0:

     curl -i "http://localhost:8080/api/frame_state?frame=0&min_conf=1.0"

  2. Or drag the Confidence Threshold slider in the web UI fully to 1.00.



Expected Result:

  HTTP 200 OK returning an empty overlay list ("overlays": []) because no

  detection has confidence >= 1.0.



Actual Result:

  HTTP 500 Internal Server Error:

  {"error": "ZeroDivisionError: float division by zero"}

  The web UI canvas crashes with STREAM ERROR: 500 (ZeroDivisionError).



Root-Cause Analysis:

  app.py contains an erroneous calculation:

    if min_conf >= 1.0:

        _norm_factor = 1.0 / (1.0 - min_conf)

  When min_conf == 1.0, the denominator (1.0 - 1.0) evaluates to zero,

  raising an unhandled exception.


BUG-03: Strict Inequality Exclusion of Boundary Confidence Detections


ICD Requirement Violated:

  ICD-1.2 (Confidence Thresholding)



Severity:

  Medium



Subsystem:

  Detection Filtering Logic (GET /api/frame_state)



Steps to Reproduce:

  1. Inspect Frame 0 detections: Target TRK-101 has conf = 0.92.

  2. Query frame 0 specifying min_conf=0.92:

     curl -s "http://localhost:8080/api/frame_state?frame=0&min_conf=0.92"



Expected Result:

  TRK-101 must be included in the overlays array per ICD requirement

  conf >= min_conf.



Actual Result:

  Response payload:

  {

    "frame_id": 0,

    "overlays": []

  }

  Target TRK-101 is dropped.



Root-Cause Analysis:

  The list comprehension in app.py uses strict greater-than:

    overlays = [d for d in overlay_frame["detections"] if d["conf"] > min_conf]

  It must be inclusive (>=).



BUG-04: Transposed WGS-84 Geographic Coordinate Ordering (Lat/Lon Swapped)


ICD Requirement Violated:

  ICD-2.1 (WGS-84 Geo Coordinates)



Severity:

  Critical



Subsystem:

  Geo-Mapping Service (GET /api/alerts)



Steps to Reproduce:

  1. Fetch active alerts from the API:

     curl -s "http://localhost:8080/api/alerts?page=1&limit=5"

  2. Inspect coordinates for Alert ID 1.



Expected Result:

  Standard (lat, lon) projection matching site ground truth:

  "lat": 28.6139, "lon": 77.2090 (Northern India operational sector).



Actual Result:

  Response payload:

  {

    "id": 1,

    "track_id": "TRK-101",

    "lat": 77.209,

    "lon": 28.6139,

    "severity": "HIGH"

  }

  Latitude is set to 77.209 and longitude to 28.6139. In GIS map visualizers,

  this plots targets off the coast of Western Australia in the Indian Ocean.



Root-Cause Analysis:

  The alert serialization dictionary in app.py inverts coordinate keys:

    out.append({

        ...

        "lat": a["lon"],

        "lon": a["lat"],

        ...

    })



BUG-05: Alert Pagination Slice Off-by-One Data Truncation


ICD Requirement Violated:

  ICD-2.3 (Pagination Integrity)



Severity:

  Medium



Subsystem:

  Alerts Query Engine (GET /api/alerts)



Steps to Reproduce:

  1. Ensure initial alert count is 5 items.

  2. Request page 1 with page size 5:

     curl -s "http://localhost:8080/api/alerts?page=1&limit=5"



Expected Result:

  Response metadata indicates "total": 5, and the alerts list contains all

  5 records (IDs 1 through 5).


Actual Result:

  Response payload:

  {

    "total": 5,

    "page": 1,

    "limit": 5,

    "alerts": [{"id": 1}, {"id": 2}, {"id": 3}, {"id": 4}]

  }

  Only 4 items are returned (len(alerts) == 4). Alert ID 5 is truncated.


Root-Cause Analysis:

  The slicing index in do_GET subtracts 1 from end:

    sliced = STATE["alerts"][start : max(start, end - 1)]

  This drops the last element of every page window.


BUG-06: Non-Idempotent Stream Reconnect Generating Duplicate Alert Tracks


ICD Requirement Violated:

  ICD-2.4 (Stream Reconnect Idempotency)


Severity:

  High

Subsystem:

  Stream Recovery Handler (POST /api/stream/reconnect)


Steps to Reproduce:

  1. Observe initial state: 5 alerts in STATE["alerts"].

  2. Trigger stream reconnection:

     curl -s -X POST "http://localhost:8080/api/stream/reconnect"

  3. Query total alerts:

     curl -s "http://localhost:8080/api/alerts?page=1&limit=20"



Expected Result:

  Existing alerts for tracks already logged in previous frames must not duplicate.

  Reconnect counter increments, but total remains 5.


Actual Result:

  Alert total expands to 10. INITIAL_ALERTS are duplicated into memory:

  {"id": 6, "track_id": "TRK-101", "frame_id": 0, "conf": 0.92},

  {"id": 7, "track_id": "TRK-999", "frame_id": 0, "conf": 0.22}


Root-Cause Analysis:

  The handler blindly appends copies without checking for existing

  (track_id, frame_id) tuples:

    for a in INITIAL_ALERTS:

        dup = copy.deepcopy(a)

        dup["id"] = next_id

        STATE["alerts"].append(dup)


BUG-07: Authorization Privilege Escalation (Viewer Can Delete Alerts)

ICD Requirement Violated:

  ICD-3.1 (Tiered RBAC)



Severity:

  Critical



Subsystem:

  RBAC & Mutation Endpoints (DELETE /api/alerts/<id>)



Steps to Reproduce:

  1. Issue a deletion request with X-Role: viewer on Alert 1 (severity: HIGH):

     curl -i -X DELETE "http://localhost:8080/api/alerts/1" -H "X-Role: viewer"



Expected Result:

  HTTP 403 Forbidden. Viewers have strictly read-only permissions across all

  alert severities.



Actual Result:

  HTTP 200 OK:

  {"deleted": 1}

  The alert is purged from system state by a read-only role.



Root-Cause Analysis:

  The authorization check restricts deletion only if severity is "CRITICAL":

    if role == "viewer" and target.get("severity") == "CRITICAL":

        self._send(403, {"error": "viewer cannot delete alerts"})

        return

  Because alerts only carry "HIGH", "MEDIUM", or "LOW" tiers, viewer deletions

  bypass this guard completely.


BUG-08: Unrestricted Camera Sensor Provisioning & Lack of Input Sanitization


ICD Requirement Violated:

  ICD-3.1 & ICD-3.2 (Sensor Provisioning & Sanitization)



Severity:

  High



Subsystem:

  Hardware Stream Manager (POST /api/cameras)



Steps to Reproduce:

  1. Submit a camera creation request as operator or viewer with negative FPS

     and unsanitized HTML/JS:

     curl -i -X POST "http://localhost:8080/api/cameras" \

       -H "X-Role: operator" \

       -H "Content-Type: application/json" \

       -d '{"name": "<img src=x onerror=alert(1)>", "fps": -60}'



Expected Result:

  HTTP 403 Forbidden (only admin may add sensors). If executed by admin,

  HTTP 400 Bad Request must reject negative FPS or unsanitized payloads.



Actual Result:

  HTTP 201 Created:

  {

    "id": "CAM-03",

    "name": "<img src=x onerror=alert(1)>",

    "fps": -60,

    "status": "ONLINE"

  }

  The sensor is registered. In the browser, the script executes in the DOM

  via camBanner.innerHTML.



Root-Cause Analysis:

  do_POST under /api/cameras contains zero role validation (role != "admin"),

  does not enforce FPS bounds (1 <= fps <= 120), and fails to sanitize HTML.


3. GOLDEN-SCENARIO PRE-DEPLOYMENT RELEASE CHECKLIST


3.1. Optical Ground Truth & Edge Case Replay

[ ] Target Dimension Limits: Stream golden clips with vehicles scaled between

    minimum detection resolution (12 pixels on target) and maximum field of view

    (full-frame convoy). Confirm zero bounding box inversions (w <= 0, h <= 0).

[ ] Diurnal Thermal Inversion: Replay dawn/dusk infrared crossover footage where

    ambient terrain temperatures match vehicle hull temperatures. Verify target

    continuity: track IDs (TRK-XXX) must persist without identity swaps or rapid

    fragmentation.

[ ] Clutter & Countermeasure Suppression: Replay sequences with solar glint,

    decoy flares, vehicle exhaust plumes, and smoke obscurants. Verify clutter

    confidence ratings remain below 0.50 (LOW) and generate zero false alarms.



3.2. Telemetry Timing & Clock Drift Stability

[ ] Zero-Drift Endurance Under Network Jitter: Inject synthetic packet jitter

    (50 ms to 250 ms) on the incoming video transport. Confirm

    overlay_pts_ms == video_pts_ms continuously across >= 10,000 consecutive

    frames without temporal drift.

[ ] Hard Stream Disconnect Recovery: Simulate physical cable disconnects and

    abrupt RTSP drops. Confirm stream reconnection occurs in <= 500 ms,

    reconnect telemetry increments accurately, and existing track IDs are

    deduplicated.



3.3. Cyber Hardening & Fail-Safe Operations

[ ] Role Isolation Enforcement: Attempt state mutation across all endpoints

    using viewer and operator credentials. Verify all mutating routes reject

    unauthorized requests with HTTP 403.

[ ] XSS & Telemetry Sanitization: Verify camera labels, track tags, and user

    inputs containing control characters, null bytes, or HTML/script tags are

    escaped before browser rendering.

[ ] 24-Hour Soak & Memory Leak Profile: Run uninterrupted 25 FPS stream playback

    at maximum target density for 24 hours. Process memory footprint must remain

    stable with <= +/- 5% variation, demonstrating zero unbounded queue growth.